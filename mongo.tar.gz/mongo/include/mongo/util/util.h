// Do not add anything new to this file. 
// Find a better/more appropriate place instead.

#pragma once

#include <cstddef>

namespace mongo {

    void sayDbContext(const char *msg = NULL);

} // namespace mongo
